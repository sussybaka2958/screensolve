# ScreenSolve for Windows

ScreenSolve is a visible Windows 11-style desktop utility: users sign in, press **Ctrl+Shift+Space**, drag a screen region (or press Enter for the active virtual monitor), optionally type a question, and receive a Gemini answer from the existing protected Supabase Edge Function.

It deliberately does not hide from Alt+Tab, the taskbar, screen recordings, accessibility APIs, or screen sharing. It has no stealth, anti-recording, anti-cheat, or proctoring-evasion behavior.

## Security boundary

- The client stores an encrypted session locally using Windows DPAPI scoped to the signed-in Windows user.
- It ships only the Supabase URL and publishable/anon key in `supabase_config.json`.
- Gemini, Stripe secret, Stripe webhook secret, Supabase service-role key, and administrator credentials are never client configuration.
- The Edge Function verifies the caller and reserves/refunds quota server-side. The desktop client never determines billing status.

See [Docs/BUILD.md](Docs/BUILD.md) for exact build and installer steps, and [Docs/MIGRATION.md](Docs/MIGRATION.md) for the migration notes. The required Edge Function change is supplied as [Docs/ask-screen-index.ts](Docs/ask-screen-index.ts).
