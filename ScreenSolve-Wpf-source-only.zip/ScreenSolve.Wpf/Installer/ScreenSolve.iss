#define AppName "ScreenSolve"
#define AppVersion "1.0.0"
[Setup]
AppId={{B12DA736-27D6-4651-8963-8D9D444F21C0}
AppName={#AppName}
AppVersion={#AppVersion}
DefaultDirName={autopf}\ScreenSolve
DefaultGroupName=ScreenSolve
OutputBaseFilename=ScreenSolve-Setup
Compression=lzma
SolidCompression=yes
UninstallDisplayIcon={app}\ScreenSolve.exe
[Files]
Source: "..\publish\*"; DestDir: "{app}"; Flags: recursesubdirs ignoreversion
[Icons]
Name: "{autoprograms}\ScreenSolve"; Filename: "{app}\ScreenSolve.exe"
Name: "{autodesktop}\ScreenSolve"; Filename: "{app}\ScreenSolve.exe"; Tasks: desktopicon
[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; Flags: unchecked
[Run]
Filename: "{app}\ScreenSolve.exe"; Description: "Launch ScreenSolve"; Flags: nowait postinstall skipifsilent
