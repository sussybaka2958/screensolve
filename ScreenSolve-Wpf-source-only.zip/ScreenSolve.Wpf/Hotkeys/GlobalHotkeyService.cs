using System.Runtime.InteropServices; using System.Windows.Interop;
namespace ScreenSolve.Wpf.Hotkeys;
public sealed class GlobalHotkeyService : IDisposable {
 public const string DefaultCapture="Ctrl+Shift+Space"; const int Id=0x5343, WmHotkey=0x0312; HwndSource? _source; Action? _action;
 [DllImport("user32.dll")] static extern bool RegisterHotKey(IntPtr hWnd,int id,uint modifiers,uint key); [DllImport("user32.dll")] static extern bool UnregisterHotKey(IntPtr hWnd,int id);
 public void Register(string hotkey, Action action) { Dispose(); _action=action; var p=new HwndSourceParameters("ScreenSolve.Hotkeys"){Width=0,Height=0,WindowStyle=0}; _source=new HwndSource(p); _source.AddHook(WndProc); if(!RegisterHotKey(_source.Handle,Id,0x0002|0x0004,0x20)) throw new InvalidOperationException("Ctrl+Shift+Space is unavailable. Change it in Settings."); }
 IntPtr WndProc(IntPtr h,int msg,IntPtr w,IntPtr l,ref bool handled) { if(msg==WmHotkey && w.ToInt32()==Id) { handled=true; _=System.Windows.Application.Current.Dispatcher.InvokeAsync(_action); } return IntPtr.Zero; }
 public void Dispose(){if(_source!=null){UnregisterHotKey(_source.Handle,Id);_source.Dispose();_source=null;}}
}
