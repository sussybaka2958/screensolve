using System.Windows;
using ScreenSolve.Wpf.Api; using ScreenSolve.Wpf.Auth; using ScreenSolve.Wpf.Storage; using ScreenSolve.Wpf.UI.Overlay;
namespace ScreenSolve.Wpf;
public partial class App : Application {
 private AppHost? _host;
 protected override async void OnStartup(StartupEventArgs e) { base.OnStartup(e); _host = new AppHost(); await _host.StartAsync(); }
 protected override void OnExit(ExitEventArgs e) { _host?.Dispose(); base.OnExit(e); }
}
public sealed class AppHost : IDisposable {
 readonly SecureSessionStore _sessions = new(); readonly ScreenSolveApiClient _api; readonly HistoryRepository _history = new();
 readonly Hotkeys.GlobalHotkeyService _hotkeys = new(); ResponseOverlay? _overlay;
 public AppHost() { _api = new ScreenSolveApiClient(_sessions); }
 public async Task StartAsync() { await _history.InitializeAsync(); if (!await _api.HasUsableSessionAsync()) { new Auth.LoginWindow(_api, OnAuthenticated).Show(); return; } OnAuthenticated(); }
 void OnAuthenticated() { _overlay ??= new ResponseOverlay(_api, _history); _hotkeys.Register(Hotkeys.GlobalHotkeyService.DefaultCapture, async () => { var result = await Capture.RegionSelectionOverlay.SelectAsync(); if (result != null) _overlay.ShowCapture(result); }); }
 public void Dispose() => _hotkeys.Dispose();
}
