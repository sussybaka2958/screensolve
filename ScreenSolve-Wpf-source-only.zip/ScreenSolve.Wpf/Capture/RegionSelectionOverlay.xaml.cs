using System.Drawing; using System.Drawing.Imaging; using System.IO; using System.Windows; using System.Windows.Controls; using System.Windows.Input;
namespace ScreenSolve.Wpf.Capture;
public partial class RegionSelectionOverlay : Window {
 System.Windows.Point _start; TaskCompletionSource<CaptureResult?> _completion=new();
 public RegionSelectionOverlay(){InitializeComponent(); Left=SystemParameters.VirtualScreenLeft;Top=SystemParameters.VirtualScreenTop;Width=SystemParameters.VirtualScreenWidth;Height=SystemParameters.VirtualScreenHeight;}
 public static async Task<CaptureResult?> SelectAsync(){var w=new RegionSelectionOverlay();w.Show();return await w._completion.Task;}
 void OnDown(object s,MouseButtonEventArgs e){_start=e.GetPosition(this); Selection.Visibility=SizeLabel.Visibility=Visibility.Visible; Canvas.SetLeft(Selection,_start.X);Canvas.SetTop(Selection,_start.Y);Mouse.Capture(this);}
 void OnMove(object s,MouseEventArgs e){if(!IsMouseCaptured)return;var p=e.GetPosition(this);var x=Math.Min(p.X,_start.X);var y=Math.Min(p.Y,_start.Y);var w=Math.Abs(p.X-_start.X);var h=Math.Abs(p.Y-_start.Y);Canvas.SetLeft(Selection,x);Canvas.SetTop(Selection,y);Selection.Width=w;Selection.Height=h;SizeText.Text=$"{w:0} × {h:0}";Canvas.SetLeft(SizeLabel,x);Canvas.SetTop(SizeLabel,Math.Max(0,y-30));}
 void OnUp(object s,MouseButtonEventArgs e){Mouse.Capture(null);if(Selection.Width<4||Selection.Height<4){Finish(null);return;} Finish(Capture(new Rect(Left+Canvas.GetLeft(Selection),Top+Canvas.GetTop(Selection),Selection.Width,Selection.Height)));}
 void OnKeyDown(object s,KeyEventArgs e){if(e.Key==Key.Escape)Finish(null);if(e.Key==Key.Enter)Finish(Capture(new Rect(Left,Top,Width,Height)));}
 CaptureResult Capture(Rect r){var bmp=new Bitmap((int)r.Width,(int)r.Height,PixelFormat.Format32bppArgb);using var g=Graphics.FromImage(bmp);g.CopyFromScreen((int)r.X,(int)r.Y,0,0,bmp.Size);using var ms=new MemoryStream();bmp.Save(ms,ImageFormat.Png);return new CaptureResult(ms.ToArray(),r);}
 void Finish(CaptureResult? r){Close();_completion.TrySetResult(r);} protected override void OnClosed(EventArgs e){_completion.TrySetResult(null);base.OnClosed(e);}
}
