using System.Windows;
namespace ScreenSolve.Wpf.Capture;
public sealed record CaptureResult(byte[] Png, Rect Bounds);
