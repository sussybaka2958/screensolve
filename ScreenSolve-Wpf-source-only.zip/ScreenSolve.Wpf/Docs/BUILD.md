# Build and package

1. Install the [.NET 8 SDK](https://dotnet.microsoft.com/download/dotnet/8.0) (the runtime alone is not sufficient).
2. In `ScreenSolve.Wpf`, copy `supabase_config.json` and replace only `url` and `publishable_key` with the Supabase public values.
3. Run `dotnet restore`, then `dotnet build -c Release`.
4. Publish a self-contained Windows build: `dotnet publish -c Release -r win-x64 --self-contained true -o publish`.
5. Install Inno Setup 6 and compile `Installer\ScreenSolve.iss`. The installer is written to `Installer\Output` and includes install, uninstall, Start Menu, and optional desktop shortcut support.
6. To code-sign, sign the published EXE and the final setup EXE using your organization’s certificate and `signtool`; never store the certificate password in this repository.

Before release, test account confirmation/sign-in, restart persistence, capture/Enter/Escape, inactive/quota responses, click-through header interaction, local history, and installation on a clean Windows user profile.
