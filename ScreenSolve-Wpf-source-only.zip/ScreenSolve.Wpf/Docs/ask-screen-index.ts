// Replace the existing ask-screen/index.ts with this version, then deploy with JWT verification enabled.
import { createClient } from "npm:@supabase/supabase-js@2";
const json=(body:unknown,status=200)=>Response.json(body,{status,headers:{"Content-Type":"application/json"}});
Deno.serve(async request=>{
 if(request.method!=="POST")return json({error:"POST required"},405);
 const authorization=request.headers.get("Authorization"); if(!authorization?.startsWith("Bearer "))return json({error:"Sign in required"},401);
 const supabase=createClient(Deno.env.get("SUPABASE_URL")!,Deno.env.get("SUPABASE_ANON_KEY")!,{global:{headers:{Authorization:authorization}}});
 const {data:{user},error:authError}=await supabase.auth.getUser(); if(authError||!user)return json({error:"Invalid session"},401);
 let image:string,question=""; try {const body=await request.json();image=body.image;question=typeof body.question==="string"?body.question.trim().slice(0,4000):"";}catch{return json({error:"Invalid request"},400);}
 if(!image||image.length>10_000_000)return json({error:"Screenshot is missing or too large."},400);
 const {data:allowed,error:quotaError}=await supabase.rpc("consume_screen_request");if(quotaError||!allowed)return json({error:"Your plan is inactive or its monthly allowance is used."},403);
 let refundable=true;const refund=async()=>{if(refundable){refundable=false;const {error}=await supabase.rpc("refund_screen_request");if(error)console.error("Could not refund request",error.message);}};
 let google:Response;try{google=await fetch("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.6-flash:generateContent",{method:"POST",headers:{"Content-Type":"application/json","x-goog-api-key":Deno.env.get("GEMINI_API_KEY")!},body:JSON.stringify({contents:[{parts:[{inline_data:{mime_type:"image/png",data:image}},{text:`Study this screenshot and help concisely. ${question?`User question: ${question}`:""} Use clear Markdown when it helps."}]}]})});}catch{await refund();return json({error:"The answer service is temporarily unavailable."},502);}
 if(!google.ok){await refund();return json({error:"The answer service is temporarily unavailable."},502);}let result:any;try{result=await google.json();}catch{await refund();return json({error:"The answer service is temporarily unavailable."},502);}
 const text=result?.candidates?.[0]?.content?.parts?.map((p:{text?:string})=>p.text??"").join("").trim();if(!text){await refund();return json({error:"The model returned no answer."},502);}refundable=false;return json({text});
});
