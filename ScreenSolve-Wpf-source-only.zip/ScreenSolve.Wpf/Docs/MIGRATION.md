# ScreenSolve WPF migration

The Python/Tkinter application is preserved in the original `ScreenSolve-app-source` folder. This replacement is a .NET 8 WPF client with a normal taskbar-visible response window, DPAPI-protected session file, native `RegisterHotKey`, region selection, authenticated Supabase requests, and a local SQLite conversation history.

The public Supabase URL/key belong in `supabase_config.json`. The file deliberately contains only public configuration. The Gemini and Stripe secrets remain server-side.

The current Edge Function is non-streaming. The client therefore shows an honest “Thinking…” state rather than claiming token streaming.
