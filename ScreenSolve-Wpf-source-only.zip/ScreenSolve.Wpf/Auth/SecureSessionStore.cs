using System.IO; using System.Security.Cryptography; using System.Text; using System.Text.Json;
namespace ScreenSolve.Wpf.Auth;
public record Session(string AccessToken, string? RefreshToken, string? Email);
public sealed class SecureSessionStore {
 readonly string _path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "ScreenSolve", "session.bin");
 public async Task SaveAsync(Session session) { Directory.CreateDirectory(Path.GetDirectoryName(_path)!); var plain=Encoding.UTF8.GetBytes(JsonSerializer.Serialize(session)); var cipher=ProtectedData.Protect(plain, null, DataProtectionScope.CurrentUser); await File.WriteAllBytesAsync(_path,cipher); }
 public async Task<Session?> ReadAsync() { try { var bytes=ProtectedData.Unprotect(await File.ReadAllBytesAsync(_path),null,DataProtectionScope.CurrentUser); return JsonSerializer.Deserialize<Session>(bytes); } catch { return null; } }
 public void Clear() { if(File.Exists(_path)) File.Delete(_path); }
}
