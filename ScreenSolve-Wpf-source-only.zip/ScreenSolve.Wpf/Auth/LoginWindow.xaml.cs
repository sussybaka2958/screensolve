using System.Windows; using ScreenSolve.Wpf.Api;
namespace ScreenSolve.Wpf.Auth;
public partial class LoginWindow : Window { readonly ScreenSolveApiClient _api; readonly Action _complete; public LoginWindow(ScreenSolveApiClient api,Action complete){InitializeComponent();_api=api;_complete=complete;}
 async void SignIn(object s,RoutedEventArgs e){try{await _api.SignInAsync(Email.Text.Trim(),Password.Password);Done();}catch(Exception x){Error.Text=x.Message;}}
 async void SignUp(object s,RoutedEventArgs e){try{if(!await _api.SignUpAsync(Email.Text.Trim(),Password.Password)){Error.Foreground=System.Windows.Media.Brushes.LightGreen;Error.Text="Check your email to confirm your account, then sign in.";return;}Done();}catch(Exception x){Error.Text=x.Message;}}
 void Done(){Close();_complete();}
}
